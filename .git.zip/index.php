<?php
declare(strict_types=1);
session_start();

if (isset($_SESSION['user_id'])) {
    switch ($_SESSION['role']) {
        case 'admin':
            header('Location: /Web/Hospital-Management-System/modules/admin/dashboard.php');
            break;
        default:
            header('Location: /Web/Hospital-Management-System/login.php');
            break;
    }
    exit();
}

header('Location: /Web/Hospital-Management-System/login.php');
exit();