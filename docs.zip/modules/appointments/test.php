<?php
// 1. පරිශීලකයා ලොග් වී ඇත්දැයි පරීක්ෂා කිරීම (Session Check)
require_once '../../includes/session_check.php';

// 2. පිටුවේ මූලික සැකසුම්


// 3. Header සහ Sidebar එකතු කිරීම
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>